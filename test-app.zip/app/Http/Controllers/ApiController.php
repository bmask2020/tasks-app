<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Users;
use Carbon\Carbon;
use Illuminate\Support\Facades\Hash;

class ApiController extends Controller
{
    
    
    public function register(Request $request) {

        if($request->isMethod('post')) {

            $validated = $request->validate([
                'name' => 'required|max:255',
                'email' => 'required|unique:posts|max:255',
                'password' => 'required'
            ]);


            $name       = strip_tags($request->name);
            $email      = strip_tags($request->email);
            $password   = $request->password;

            $data = new User;
            $data->name = $name;
            $data->email = $email;
            $data->password = Hash::make($password);
            $data->created_at = Carbon::now();
            $data->save();
           
            if($data) {

                $token = $user->user()->createToken('password');

                return response->json([
                    'message'   => 'success',
                    'token'     => $token->token
                ], 200);

            } else {

                return response->json([
                    'message'   => 'failed',
                ], 404);

            }
           

        } else {

            return response()->json([
                'message' => 'Not Allow'
            ], 404);

        } 

    } // End Method



    public function login(Request $request) {

        if($request->isMethod('post')) {

            return response()->json('working', 200);

        } else {

            return response()->json([
                'message' => 'Not Allow'
            ], 404);

        }

    } // End Method



    public function all_tasks() {

        return response()->json([
            'message' => 'Not Allow'
        ], 404);

    } // End Method


    public function tasks_store(Request $request) {

        if($request->isMethod('post')) {


        } else {


        }

    } // End Method


    public function tasks_view($id) {


    } // End Method



    public function tasks_update(Request $request, $id) {


         
    } // End Method



    public function tasks_search($title) {


    }  // End Method



    public function tasks_status($status) {


    } // End Method


    public function logout() {


    } // End Method

}
