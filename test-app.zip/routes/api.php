<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ApiController;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');




Route::any('register', [ApiController::class, 'register']);

Route::any('login', [ApiController::class, 'login']);

Route::any('logout', [ApiController::class, 'logout']);


Route::get('tasks', [ApiController::class, 'all_tasks']);
Route::any('tasks/store', [ApiController::class, 'tasks_store']);
Route::get('tasks/{id}', [ApiController::class, 'tasks_view']);
Route::any('tasks/{id}/update', [ApiController::class, 'tasks_update']);
Route::any('tasks/search/{title}', [ApiController::class, 'tasks_search']);
Route::any('tasks/status/{status}', [ApiController::class, 'tasks_status']);